let adminProvider;
let adminSigner;
let adminContract;
let isFirstNgoSet = false;


function createStatusMessage(type, message) {
    let icon, colorClass;
    switch(type) {
        case 'error': icon = '<i class="bi bi-exclamation-circle-fill"></i>'; colorClass = 'status-error'; break;
        case 'success': icon = '<i class="bi bi-check-circle-fill"></i>'; colorClass = 'status-success'; break;
        case 'loading': icon = '<i class="bi bi-arrow-repeat spin"></i>'; colorClass = 'status-loading'; break;
        case 'info': icon = '<i class="bi bi-info-circle-fill"></i>'; colorClass = 'status-info'; break;
        case 'warning': icon = '<i class="bi bi-exclamation-triangle-fill"></i>'; colorClass = 'status-warning'; break;
        default: icon = ''; colorClass = '';
    }
    return `<div class="status-message ${colorClass}">${icon} ${message}</div>`;
}

function getProposalTypeName(pType) {
    switch (pType) {
        case 0: return 'REGISTER_NGO';
        case 1: return 'SUSPEND_NGO';
        case 2: return 'REACTIVATE_NGO';
        case 3: return 'UPDATE_GOAL';
        default: return 'UNKNOWN';
    }
}

async function checkAdminAccess() {
    try {
        adminProvider = new ethers.providers.Web3Provider(window.ethereum);
        adminSigner = adminProvider.getSigner();
        adminContract = new ethers.Contract(window.contractAddress, window.contractABI, adminSigner);

        const currentAddress = (await adminSigner.getAddress()).toLowerCase();
        const adminAddress = (await adminContract.owner()).toLowerCase();
        
        if (currentAddress === adminAddress) {
            document.getElementById('adminWalletStatus').innerHTML = createStatusMessage('success', `Connected as Admin: ${currentAddress}`);
            document.getElementById('adminContent').style.display = 'block';
            await updateRegistrationUI();
        } else {
            document.getElementById('adminWalletStatus').innerHTML = createStatusMessage('error', 'Access denied: Not the admin.');
            document.getElementById('adminContent').style.display = 'none';
        }
    } catch (error) {
        console.error("Wallet access check failed:", error);
        document.getElementById('adminWalletStatus').innerHTML = createStatusMessage('error', 'Failed to verify wallet. Ensure you are on the correct network.');
    }
}

async function connectAdminWallet() {
    try {
        await ethereum.request({ method: 'eth_requestAccounts' });
        await checkAdminAccess();
    } catch (error) {
        console.error("Wallet connection failed:", error);
        document.getElementById('adminWalletStatus').innerHTML = createStatusMessage('error', 'Failed to connect wallet.');
    }
}

async function updateRegistrationUI() {
    try {
        const ngoAddresses = await adminContract.ngoList(0).catch(() => []);
        isFirstNgoSet = ngoAddresses.length > 0;
        document.getElementById('ngoRegistrationHint').textContent = isFirstNgoSet
            ? "First NGO is set. New NGOs must be proposed."
            : "No NGOs found. You can register the first NGO directly.";

        const currentQuorum = await adminContract.quorumVotes();
        document.getElementById('currentQuorum').textContent = currentQuorum.toString();
    } catch (error) {
        console.error("Failed to update UI state:", error);
        document.getElementById('ngoRegistrationHint').textContent = "Could not fetch contract status.";
    }
}

async function setQuorum() {
    const status = document.getElementById('quorumStatus');
    const newValue = document.getElementById('newQuorumValue').value;

    if (!newValue || Number(newValue) <= 0) {
        status.innerHTML = createStatusMessage('error', 'Please enter a valid, positive number for the quorum.');
        return;
    }

    try {
        status.innerHTML = createStatusMessage('loading', 'Submitting transaction to update quorum...');
        const tx = await adminContract.setQuorumVotes(newValue);
        await tx.wait();
        status.innerHTML = createStatusMessage('success', 'Quorum updated successfully!');
        const currentQuorum = await adminContract.quorumVotes();
        document.getElementById('currentQuorum').textContent = currentQuorum.toString();
        document.getElementById('newQuorumValue').value = '';
    } catch (error) {
        console.error("Failed to set quorum:", error);
        status.innerHTML = createStatusMessage('error', 'Transaction failed. See console for details.');
    }
}

async function submitNGO() {
    const statusText = document.getElementById('registerNGOStatus');
    const address = document.getElementById('newNGOAddress').value.trim();
    const name = document.getElementById('newNGOName').value.trim();
    const goal = document.getElementById('newNGOGoal').value.trim();

    if (!ethers.utils.isAddress(address) || !name || !goal) {
        statusText.innerHTML = createStatusMessage('error', 'Address, Name, and Goal are required.');
        return;
    }

    try {
    let tx;
    let successMessage = ''; 

    if (!isFirstNgoSet) {
        statusText.innerHTML = createStatusMessage('loading', 'Registering first NGO directly...');
        tx = await adminContract.setFirstNGO(address, name, goal);
        successMessage = `NGO "${name}" has been successfully registered.`; 
    } else {
        statusText.innerHTML = createStatusMessage('loading', 'Submitting proposal to register new NGO...');
        tx = await adminContract.propose(0, address, name, goal);
        successMessage = `Proposal to register "${name}" has been created successfully.`;
    }
    
    await tx.wait();
    
    statusText.innerHTML = createStatusMessage('success', successMessage); 
    
    await updateRegistrationUI();

} catch (error) {
    console.error("NGO submission failed:", error);
    const actionText = !isFirstNgoSet ? 'register the first NGO' : 'propose the new NGO';
    statusText.innerHTML = createStatusMessage('error', `Failed to ${actionText}. Please check the console for details.`);
}
}

async function proposeStatusChange(isSuspension) {
    const statusText = document.getElementById('statusChangeStatus');
    const address = document.getElementById('statusChangeNGOAddress').value.trim();

    if (!ethers.utils.isAddress(address)) {
        statusText.innerHTML = createStatusMessage('error', 'NGO Address is required.');
        return;
    }

    const pType = isSuspension ? 1 : 2;
    const actionText = isSuspension ? 'suspension' : 'reactivation';

    try {
        statusText.innerHTML = createStatusMessage('loading', `Submitting ${actionText} proposal...`);
        const tx = await adminContract.propose(pType, address, "", 0);
        await tx.wait();
        statusText.innerHTML = createStatusMessage('success', `Proposal for ${actionText} submitted successfully!`);
    } catch (error) {
        console.error(`Proposal for ${actionText} failed:`, error);
        statusText.innerHTML = createStatusMessage('error', 'Transaction failed. Check console.');
    }
}

async function fetchActiveProposals() {
    const list = document.getElementById('proposalsList');
    const status = document.getElementById('proposalsStatus');
    
    try {
        status.innerHTML = createStatusMessage('loading', 'Fetching active proposals...');
        const proposals = await adminContract.getActiveProposals();
        const quorum = await adminContract.quorumVotes();
        list.innerHTML = '';

        if (proposals.length === 0) {
            status.innerHTML = createStatusMessage('info', 'No active proposals found.');
            return;
        }
        status.innerHTML = '';

        for (const p of proposals) {
            const li = document.createElement('li');
            li.className = 'proposal-item';
            const pTypeStr = getProposalTypeName(p.pType);
            
            const isReadyToExecute = (p.votesFor.toNumber() > p.votesAgainst.toNumber()) && (p.votesFor.toNumber() + p.votesAgainst.toNumber()) >= quorum.toNumber();

            let executeButtonHtml = '';
            if (isReadyToExecute) {
                executeButtonHtml = `<button class="proposal-execute-btn" onclick="executeProposal(${p.id})">Execute</button>`;
            }

            li.innerHTML = `
                <div class="proposal-header">
                    <div class="proposal-title">ID: ${p.id} - ${pTypeStr}</div>
                    <div class="proposal-actions">${executeButtonHtml}</div>
                </div>
                <div class="proposal-details">
                    <div>Target NGO: ${p.ngoName} (${p.ngoAddress})</div>
                    <div>Votes: ${p.votesFor.toString()} For / ${p.votesAgainst.toString()} Against (Quorum: ${quorum.toString()})</div> 
                </div>
            `;
            list.appendChild(li);
        }
    } catch (err) {
        console.error('Error fetching proposals:', err);
        status.innerHTML = createStatusMessage('error', 'Failed to fetch proposals.');
    }
}

async function executeProposal(proposalId) {
    const status = document.getElementById('proposalsStatus');
    try {
        status.innerHTML = createStatusMessage('loading', `Executing proposal #${proposalId}...`);
        const tx = await adminContract.executeProposal(proposalId);
        await tx.wait();
        status.innerHTML = createStatusMessage('success', `Proposal #${proposalId} executed successfully!`);
        await fetchActiveProposals();
    } catch (err) {
        console.error('Execution failed:', err);
        status.innerHTML = createStatusMessage('error', `Execution of proposal #${proposalId} failed. The contract reverted the transaction.`);
    }
}

window.addEventListener('DOMContentLoaded', () => {
    document.getElementById('connectAdminWalletButton').addEventListener('click', connectAdminWallet);
    document.getElementById('submitNGOButton').addEventListener('click', submitNGO);
    document.getElementById('proposeSuspendButton').addEventListener('click', () => proposeStatusChange(true));
    document.getElementById('proposeReactivateButton').addEventListener('click', () => proposeStatusChange(false));
    document.getElementById('fetchProposalsButton').addEventListener('click', fetchActiveProposals);
    document.getElementById('setQuorumButton').addEventListener('click', setQuorum);

    if (window.ethereum) {
        window.ethereum.on('accountsChanged', () => checkAdminAccess());
    }
});