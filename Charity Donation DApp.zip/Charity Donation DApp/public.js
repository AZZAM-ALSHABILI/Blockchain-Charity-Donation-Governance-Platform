let provider;
let signer;
let contract;

let isUserDonor = false;
let currentUserAddress = '';


function getProposalTypeName(pType) {
    switch (pType) {
        case 0: return 'REGISTER_NGO';
        case 1: return 'SUSPEND_NGO';
        case 2: return 'REACTIVATE_NGO';
        case 3: return 'UPDATE_GOAL';
        default: return 'UNKNOWN';
    }
}

function createStatusMessage(type, message) {
    let icon, colorClass;
    switch(type) {
        case 'error': icon = '<i class="bi bi-exclamation-circle-fill"></i>'; colorClass = 'status-error'; break;
        case 'success': icon = '<i class="bi bi-check-circle-fill"></i>'; colorClass = 'status-success'; break;
        case 'loading': icon = '<i class="bi bi-arrow-repeat spin"></i>'; colorClass = 'status-loading'; break;
        case 'info': icon = '<i class="bi bi-info-circle-fill"></i>'; colorClass = 'status-info'; break;
        case 'warning': icon = '<i class="bi bi-exclamation-triangle-fill"></i>'; colorClass = 'status-warning'; break;
        default: icon = ''; colorClass = '';
    }
    return `<div class="status-message ${colorClass}">${icon} ${message}</div>`;
}

// --- WEB3 & CORE FUNCTIONS ---

async function connectWallet() {
    if (typeof window.ethereum === 'undefined') {
        return alert('Please install MetaMask!');
    }
    
    try {
        await ethereum.request({ method: 'eth_requestAccounts' });
        provider = new ethers.providers.Web3Provider(window.ethereum);
        signer = provider.getSigner();
        contract = new ethers.Contract(window.contractAddress, window.contractABI, signer);
        
        currentUserAddress = await signer.getAddress();
        document.getElementById('walletAddress').innerHTML = createStatusMessage('success', `Connected: ${currentUserAddress}`);

        await checkUserRoles(currentUserAddress);

    } catch (error) {
        console.error(error);
        document.getElementById('walletAddress').innerHTML = createStatusMessage('error', 'Failed to connect wallet.');
    }
}

async function checkUserRoles(address) {
    try {
        const ngo = await contract.ngos(address);
        if (ngo.isRegistered) {
            document.getElementById('ngoTools').style.display = 'block';
            document.getElementById('goalRequestSection').style.display = 'block';
        } else {
            document.getElementById('ngoTools').style.display = 'none';
            document.getElementById('goalRequestSection').style.display = 'none';
        }
        
        isUserDonor = await contract.isDonor(address);
        const governanceSection = document.getElementById('governanceSection');
        if (isUserDonor) {
            governanceSection.style.display = 'block';
        } else {
            governanceSection.style.display = 'none';
        }
    } catch (err) {
        console.error("Could not verify user roles:", err);
        document.getElementById('ngoTools').style.display = 'none';
        document.getElementById('goalRequestSection').style.display = 'none';
    }
}

async function makeDonation() {
    const amountEth = document.getElementById('donationAmount').value;
    const ngoAddress = document.getElementById('ngoAddress').value.trim().toLowerCase();
    const donationStatus = document.getElementById('donationStatus');

    if (!ethers.utils.isAddress(ngoAddress) || !amountEth || isNaN(amountEth) || Number(amountEth) <= 0) {
        donationStatus.innerHTML = createStatusMessage('error', 'Please enter a valid address and amount.');
        return;
    }

    try {
        donationStatus.innerHTML = createStatusMessage('loading', 'Sending donation...');
        const tx = await contract.donate(ngoAddress, { value: ethers.utils.parseEther(amountEth) });
        await tx.wait();
        
        isUserDonor = true;
        document.getElementById('governanceSection').style.display = 'block';
        donationStatus.innerHTML = createStatusMessage('success', 'Thank you! Your vote is now enabled.');

    } catch (error) {
        console.error("Donation failed:", error);
        donationStatus.innerHTML = createStatusMessage('error', 'Donation failed.');
    }
}

async function withdrawFunds() {
    const withdrawStatus = document.getElementById('withdrawStatus');
    try {
        withdrawStatus.innerHTML = createStatusMessage('loading', 'Processing withdrawal...');
        const tx = await contract.withdrawFunds();
        await tx.wait();
        withdrawStatus.innerHTML = createStatusMessage('success', 'Withdrawal successful!');
    } catch (error) {
        console.error("Withdraw failed:", error);
        withdrawStatus.innerHTML = createStatusMessage('error', 'Withdrawal failed. Check console.');
    }
}

// --- GOVERNANCE FUNCTIONS ---

async function fetchActiveProposals() {
    const list = document.getElementById('proposalsList');
    const status = document.getElementById('proposalsStatus');
    
    try {
        status.innerHTML = createStatusMessage('loading', 'Fetching active proposals...');
        const proposals = await contract.getActiveProposals();
        const quorum = await contract.quorumVotes();
        list.innerHTML = '';

        if (proposals.length === 0) {
            status.innerHTML = createStatusMessage('info', 'No active proposals found.');
            return;
        }
        status.innerHTML = '';

        for (const p of proposals) {
            const li = document.createElement('li');
            li.className = 'proposal-card';
            const pTypeStr = getProposalTypeName(p.pType);
            
            let voteButtonsHtml = `<button class="vote-btn" disabled title="Connect wallet and become a donor to vote.">Vote</button>`;
            if (currentUserAddress && isUserDonor) {
                const hasVoted = await contract.hasVoted(p.id, currentUserAddress);
                if (hasVoted) {
                    voteButtonsHtml = `<div class="voted-text">Voted</div>`;
                } else {
                    voteButtonsHtml = `
                        <div class="vote-buttons-container">
                            <button class="vote-btn-approve" onclick="voteOnProposal(${p.id}, true)">Approve</button>
                            <button class="vote-btn-reject" onclick="voteOnProposal(${p.id}, false)">Reject</button>
                        </div>`;
                }
            }
            
            let goalDisplayHtml = '';
            if (p.pType === 0 || p.pType === 3) {
                const label = p.pType === 0 ? 'Initial Goal' : 'New Goal';
                goalDisplayHtml = `<div><strong>${label}:</strong> ${ethers.utils.formatEther(p.goalAmount)} ETH</div>`;
            }

            li.innerHTML = `
                <div class="proposal-header">
                    <div class="proposal-title">ID: ${p.id} - ${pTypeStr}</div>
                </div>
                <div class="proposal-details">
                    <div><strong>Target:</strong> ${p.ngoName} (${p.ngoAddress})</div>
                    ${goalDisplayHtml}
                    <div><strong>Votes:</strong> <span class="votes-for">${p.votesFor} For</span> / <span class="votes-against">${p.votesAgainst} Against</span> (Quorum: ${quorum})</div>
                </div>
                <div class="proposal-actions">
                    ${voteButtonsHtml}
                </div>
            `;
            list.appendChild(li);
        }
    } catch (err) {
        console.error('Error fetching proposals:', err);
        status.innerHTML = createStatusMessage('error', 'Failed to fetch proposals.');
    }
}

async function voteOnProposal(proposalId, supports) {
    const status = document.getElementById('proposalsStatus');
    try {
        status.innerHTML = createStatusMessage('loading', `Submitting your vote for proposal #${proposalId}...`);
        const tx = await contract.vote(proposalId, supports);
        await tx.wait();
        status.innerHTML = createStatusMessage('success', `Successfully voted on proposal #${proposalId}!`);
        await fetchActiveProposals();
    } catch (err) {
        console.error('Vote failed:', err);
        status.innerHTML = createStatusMessage('error', 'Vote transaction failed. Check console.');
    }
}

async function proposeGoalUpdate() {
    const status = document.getElementById('proposeGoalUpdateStatus');
    const newGoalEth = document.getElementById('ngoNewGoalInput').value;

    if (!newGoalEth || isNaN(newGoalEth) || Number(newGoalEth) <= 0) {
        status.innerHTML = createStatusMessage('error', 'Please enter a valid goal amount.');
        return;
    }

    try {
        status.innerHTML = createStatusMessage('loading', 'Submitting goal update proposal...');
        const tx = await contract.proposeGoalUpdate(newGoalEth);
        await tx.wait();
        status.innerHTML = createStatusMessage('success', 'Goal update proposal submitted successfully!');
        document.getElementById('ngoNewGoalInput').value = '';
    } catch (error) {
        console.error("Goal update proposal failed:", error);
        status.innerHTML = createStatusMessage('error', 'Failed to submit proposal. Check console.');
    }
}

// --- STATS & VIEW FUNCTIONS ---

async function getDonationCount() {
    const status = document.getElementById('totalDonations');
    try {
        status.innerHTML = createStatusMessage('loading', 'Fetching...');
        const count = await contract.getDonationCount();
        status.innerHTML = `Total donations: ${count}`;
    } catch (error) {
        console.error(error);
        status.innerHTML = createStatusMessage('error', 'Failed to get count.');
    }
}

async function listAllDonations() {
    const listElement = document.getElementById('donationList');
    try {
        listElement.innerHTML = createStatusMessage('loading', 'Fetching all donations...');
        const donations = await contract.getAllDonations();
        listElement.innerHTML = '';
        if (donations.length === 0) {
            listElement.innerHTML = '<li>No donations yet.</li>';
            return;
        }
        donations.forEach((donation) => {
            const item = document.createElement('li');
            const shortAddress = `${donation.donor.substring(0, 6)}...${donation.donor.slice(-4)}`;
            item.innerText = `${shortAddress} donated ${ethers.utils.formatEther(donation.amount)} ETH on ${new Date(donation.timestamp * 1000).toLocaleString()}`;
            listElement.appendChild(item);
        });
    } catch (error) {
        console.error(error);
        listElement.innerHTML = createStatusMessage('error', 'Failed to list donations.');
    }
}

async function viewMyDonationHistory() {
    const listElement = document.getElementById('myDonationHistoryList');
    try {
        listElement.innerHTML = createStatusMessage('loading', 'Fetching your donation history...');
        const donorAddress = await signer.getAddress();
        const myDonations = await contract.getDonationsByDonor(donorAddress);
        listElement.innerHTML = '';
        if (myDonations.length === 0) {
            listElement.innerHTML = '<li>You have not made any donations yet.</li>';
            return;
        }
        myDonations.forEach((donation) => {
            const item = document.createElement('li');
            item.innerText = `You donated ${ethers.utils.formatEther(donation.amount)} ETH on ${new Date(donation.timestamp * 1000).toLocaleString()}`;
            listElement.appendChild(item);
        });
    } catch (error) {
        console.error(error);
        listElement.innerHTML = createStatusMessage('error', 'Failed to fetch history.');
    }
}

async function listAllNGOs() {
    const listElement = document.getElementById('ngoDirectoryList');
    try {
        listElement.innerHTML = createStatusMessage('loading', 'Fetching all NGOs...');
        const ngoAddresses = await contract.getAllNGOs();
        listElement.innerHTML = '';
        if (ngoAddresses.length === 0) {
            listElement.innerHTML = '<li>No registered NGOs yet.</li>';
            return;
        }
        for (const ngoAddress of ngoAddresses) {
            const ngoData = await contract.ngos(ngoAddress);
            const shortAddress = `${ngoAddress.substring(0, 6)}...${ngoAddress.slice(-4)}`;
            const item = document.createElement('li');
            item.innerHTML = `<strong>${ngoData.name}</strong> (${shortAddress})`;
            listElement.appendChild(item);
        }
    } catch (error) {
        console.error(error);
        listElement.innerHTML = createStatusMessage('error', 'Failed to fetch NGOs.');
    }
}

async function getNGOBalance() {
    const ngoAddress = document.getElementById('ngoBalanceAddress').value;
    const resultEl = document.getElementById('ngoBalanceResult');
    if (!ethers.utils.isAddress(ngoAddress)) {
        return resultEl.innerHTML = createStatusMessage('error', 'Invalid NGO address.');
    }
    try {
        resultEl.innerHTML = createStatusMessage('loading', 'Fetching NGO data...');
        const ngoData = await contract.ngos(ngoAddress);
        if (!ngoData.isRegistered) {
            return resultEl.innerHTML = createStatusMessage('warning', 'This address is not a registered NGO.');
        }
        const balanceEth = ethers.utils.formatEther(ngoData.balance);
        resultEl.innerHTML = createStatusMessage('success', `Balance: ${balanceEth} ETH`);
    } catch (error) {
        console.error(error);
        resultEl.innerHTML = createStatusMessage('error', 'Failed to get NGO data.');
    }
}

async function checkNGOProgress() {
    const ngoAddress = document.getElementById('ngoGoalAddress').value;
    const resultEl = document.getElementById('ngoGoalInfo');
    if (!ethers.utils.isAddress(ngoAddress)) {
        return resultEl.innerHTML = createStatusMessage('error', 'Invalid NGO address.');
    }
    try {
        resultEl.innerHTML = createStatusMessage('loading', 'Fetching goal and progress...');
        const ngoData = await contract.ngos(ngoAddress);
        if (!ngoData.isRegistered) {
            return resultEl.innerHTML = createStatusMessage('warning', 'This address is not a registered NGO.');
        }
        const goalEth = Number(ethers.utils.formatEther(ngoData.goalAmount));
        const rawProgress = await contract.getNGOProgress(ngoAddress);
        const progressPercent = (rawProgress / 100).toFixed(2);
        resultEl.innerHTML = createStatusMessage('success', `Goal: ${goalEth.toFixed(1)} ETH, Progress: ${progressPercent}%`);
    } catch (error) {
        console.error(error);
        resultEl.innerHTML = createStatusMessage('error', 'Failed to fetch goal and progress.');
    }
}

async function showTopDonors() {
    const leaderboardElement = document.getElementById('leaderboardList');
    leaderboardElement.innerHTML = createStatusMessage('loading', 'Calculating top donors...');
    try {
        const donations = await contract.getAllDonations();
        const donorTotals = {};
        donations.forEach((donation) => {
            const donor = donation.donor.toLowerCase();
            const amount = parseFloat(ethers.utils.formatEther(donation.amount));
            if (!donorTotals[donor]) {
                donorTotals[donor] = 0;
            }
            donorTotals[donor] += amount;
        });
        const sortedDonors = Object.entries(donorTotals)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 10);
        leaderboardElement.innerHTML = '';
        if (sortedDonors.length === 0) {
            leaderboardElement.innerHTML = '<li>No donations yet.</li>';
        } else {
            sortedDonors.forEach(([donor, total]) => {
                const li = document.createElement('li');
                const shortAddress = `${donor.slice(0, 6)}...${donor.slice(-4)}`;
                li.innerText = `${shortAddress} donated ${total.toFixed(2)} ETH total`;
                leaderboardElement.appendChild(li);
            });
        }
    } catch (error) {
        console.error(error);
        leaderboardElement.innerHTML = createStatusMessage('error', 'Failed to load leaderboard.');
    }
}

async function searchDonations() {
    const searchInput = document.getElementById('searchQuery').value.trim().toLowerCase();
    const resultList = document.getElementById('searchResults');
    resultList.innerHTML = '';
    if (!searchInput || !ethers.utils.isAddress(searchInput)) {
        return resultList.innerHTML = createStatusMessage('error', 'Please enter a valid Ethereum address to search.');
    }
    try {
        resultList.innerHTML = createStatusMessage('loading', 'Searching...');
        const donations = await contract.getAllDonations();
        const matches = donations.filter(donation => donation.donor.toLowerCase() === searchInput);
        if (matches.length === 0) {
            resultList.innerHTML = '<li>No matching donations found.</li>';
        } else {
            matches.forEach((donation) => {
                const li = document.createElement('li');
                li.textContent = `Donated ${ethers.utils.formatEther(donation.amount)} ETH on ${new Date(donation.timestamp * 1000).toLocaleString()}`;
                resultList.appendChild(li);
            });
        }
    } catch (err) {
        console.error(err);
        resultList.innerHTML = createStatusMessage('error', 'Failed to search donations.');
    }
}



window.addEventListener('DOMContentLoaded', () => {
    document.getElementById('connectWalletButton')?.addEventListener('click', connectWallet);
    document.getElementById('donateButton')?.addEventListener('click', makeDonation);
    document.getElementById('withdrawButton')?.addEventListener('click', withdrawFunds);
    document.getElementById('fetchProposalsButton')?.addEventListener('click', fetchActiveProposals);
    document.getElementById('proposeGoalUpdateButton')?.addEventListener('click', proposeGoalUpdate);

    
    document.getElementById('listAllNGOsButton')?.addEventListener('click', listAllNGOs);
    document.getElementById('viewMyHistoryButton')?.addEventListener('click', viewMyDonationHistory);
    document.getElementById('getCountButton')?.addEventListener('click', getDonationCount);
    document.getElementById('listDonationsButton')?.addEventListener('click', listAllDonations);
    document.getElementById('getNGOBalanceButton')?.addEventListener('click', getNGOBalance);
    document.getElementById('checkGoalButton')?.addEventListener('click', checkNGOProgress);
    document.getElementById('showLeaderboardButton')?.addEventListener('click', showTopDonors);
    document.getElementById('searchDonationButton')?.addEventListener('click', searchDonations);
    document.getElementById('listNGOsButton')?.addEventListener('click', listAllNGOs);


    if (window.ethereum) {
        window.ethereum.on('accountsChanged', () => window.location.reload());
        window.ethereum.on('chainChanged', () => window.location.reload());
    }
});